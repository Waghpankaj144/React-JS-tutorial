import React from 'react'

function ChildC({name}) {
  return (
    <div>
        <h1>The name is {name}</h1>
    </div>
  )
}

export default ChildC