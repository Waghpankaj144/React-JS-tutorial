import UpdateObjects from "../../useState/src/UpdateObjects"
import Button from "./Button"
import MyComponent from "./MyComponent"


function App() {
  
  return (
    <>
  <Button/>
  <MyComponent/>
  <UpdateObjects/>
    </>
  )
}

export default App
