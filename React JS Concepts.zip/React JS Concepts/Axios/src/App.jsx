//GET :- receiving data from server
//POST:- sending data from front end to back end
//PUT:-  



import './App.css'
import AxiosGet from './AxiosGet'
import AxiosPost from './AxiosPost'

function App() {

 

  return (
    <>
    {/* <AxiosGet/> */}
    <AxiosPost/>
        </>
  )
}

export default App
