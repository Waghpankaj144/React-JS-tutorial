import React from 'react'
import ChildC from './ChildC'

function ChildB() {
  return (
    <div>
      <ChildC/>
    </div>
  )
}

export default ChildB